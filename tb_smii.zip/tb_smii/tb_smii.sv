`timescale 1 ns/1 ns

module tb_smii();

reg rstn=1'b0;
reg phy_smii_ref_clk=1'b1;
initial #32 rstn=1'b1;
always #4 phy_smii_ref_clk=~phy_smii_ref_clk;     // 125MHz

wire       mac_mii_crs;
wire       mac_mii_rxrst;
wire       mac_mii_rxc;
wire       mac_mii_rxdv;
wire       mac_mii_rxer;
wire [3:0] mac_mii_rxd;
wire       mac_mii_txrst;
wire       mac_mii_txc;
reg        mac_mii_txen = '0;
reg        mac_mii_txer = '0;
reg  [3:0] mac_mii_txd = '0;
wire       phy_smii_sync;
reg        phy_smii_rxd = '0;
wire       phy_smii_txd;

smii_phy_if #(
    .RX_SYNC_DELAY    ( 0                )
) smii_phy_if_i(
    .rstn             ( rstn             ),
    .mac_mii_crs      ( mac_mii_crs      ),
    .mac_mii_rxrst    ( mac_mii_rxrst    ),
    .mac_mii_rxc      ( mac_mii_rxc      ),
    .mac_mii_rxdv     ( mac_mii_rxdv     ),
    .mac_mii_rxer     ( mac_mii_rxer     ),
    .mac_mii_rxd      ( mac_mii_rxd      ),
    .mac_mii_txrst    ( mac_mii_txrst    ),
    .mac_mii_txc      ( mac_mii_txc      ),
    .mac_mii_txen     ( mac_mii_txen     ),
    .mac_mii_txer     ( mac_mii_txer     ),
    .mac_mii_txd      ( mac_mii_txd      ),
    .phy_smii_ref_clk ( phy_smii_ref_clk ),
    .phy_smii_sync    ( phy_smii_sync    ),
    .phy_smii_rxd     ( phy_smii_rxd     ),
    .phy_smii_txd     ( phy_smii_txd     )
);

task automatic smii_phy_send(input [9:0] data);
    while(~rstn) #1 ;
    while(~phy_smii_sync) #1 ;
    for(int i=0; i<10; i++) begin
        phy_smii_rxd <= data[i];
        @(posedge phy_smii_ref_clk);
    end
endtask

task automatic mii_mac_send(input txen, input txer, input [3:0] txd);
    while(~rstn) #1 ;
    while(mac_mii_txrst) #1 ;
    mac_mii_txen <= txen;
    mac_mii_txer <= txer;
    mac_mii_txd <= txen ? txd : '0;
    @(posedge mac_mii_txc);
endtask

initial fork
    begin
        smii_phy_send(10'b1000101000);
        smii_phy_send(10'b0000000111);
        smii_phy_send(10'b0000001011);
        smii_phy_send(10'b0000001110);
        smii_phy_send(10'b1000101000);
        smii_phy_send(10'b0000010111);
        smii_phy_send(10'b0000011011);
        smii_phy_send(10'b0000011110);
        smii_phy_send(10'b0000100010);
        smii_phy_send(10'b1000101000);
        smii_phy_send(10'b1000101000);
        smii_phy_send(10'b0000000111);
        smii_phy_send(10'b0000001011);
        smii_phy_send(10'b0000001110);
        smii_phy_send(10'b1000101000);
        for(int i=0; i<10; i++) smii_phy_send(10'b1000100000);
        for(int i=0; i<10; i++) smii_phy_send(10'b1000100000);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000000111);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000001011);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000001110);
        for(int i=0; i<10; i++) smii_phy_send(10'b1000100000);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000010111);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000011011);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000011111);
        for(int i=0; i<10; i++) smii_phy_send(10'b0000100011);
        while(1) smii_phy_send(10'b1000100000);
    end
    begin
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b1, 1'b0, 4'h4);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b1, 1'b0, 4'h4);
        mii_mac_send(1'b1, 1'b0, 4'h5);
        mii_mac_send(1'b1, 1'b0, 4'h6);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b1, 1'b1, 4'h4);
        mii_mac_send(1'b1, 1'b0, 4'h5);
        mii_mac_send(1'b1, 1'b0, 4'h6);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b1, 4'h3);
        mii_mac_send(1'b1, 1'b0, 4'h4);
        mii_mac_send(1'b1, 1'b0, 4'h5);
        mii_mac_send(1'b1, 1'b0, 4'h6);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b1, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b1, 1'b0, 4'h4);
        mii_mac_send(1'b1, 1'b0, 4'h5);
        mii_mac_send(1'b1, 1'b0, 4'h6);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b0, 1'b0, 4'h0);
        mii_mac_send(1'b1, 1'b0, 4'h1);
        mii_mac_send(1'b1, 1'b0, 4'h2);
        mii_mac_send(1'b1, 1'b0, 4'h3);
        mii_mac_send(1'b1, 1'b0, 4'h4);
        mii_mac_send(1'b1, 1'b0, 4'h5);
        mii_mac_send(1'b1, 1'b0, 4'h6);
        mii_mac_send(1'b1, 1'b0, 4'h7);
        mii_mac_send(1'b1, 1'b0, 4'h8);
        mii_mac_send(1'b1, 1'b0, 4'h9);
        mii_mac_send(1'b1, 1'b0, 4'ha);
        while(1) mii_mac_send(1'b0, 1'b0, 4'h0);
    end
join

endmodule
